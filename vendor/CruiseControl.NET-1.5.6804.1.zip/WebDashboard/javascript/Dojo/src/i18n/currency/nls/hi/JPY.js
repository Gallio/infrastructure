
({"displayName":"\u091c\u093e\u092a\u093e\u0928\u0940 \u092f\u0947\u0928","symbol":"\xa5"})