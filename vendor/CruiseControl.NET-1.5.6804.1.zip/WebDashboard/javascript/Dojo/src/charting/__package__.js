
dojo.provide("dojo.charting.*");