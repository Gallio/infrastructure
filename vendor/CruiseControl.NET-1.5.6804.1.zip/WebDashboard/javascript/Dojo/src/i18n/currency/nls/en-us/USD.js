
({"symbol":"$","displayName":"US Dollar"})