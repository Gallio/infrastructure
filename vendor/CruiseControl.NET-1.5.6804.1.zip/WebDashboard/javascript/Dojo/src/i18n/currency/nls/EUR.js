
({"displayName":"EUR","symbol":"\u20ac"})