
({"displayName":"\u82f1\u56fd\u30dd\u30f3\u30c9","symbol":"\xa3"})