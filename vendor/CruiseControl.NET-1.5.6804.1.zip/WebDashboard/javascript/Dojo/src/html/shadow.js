
dojo.provide("dojo.html.shadow");dojo.require("dojo.lfx.shadow");dojo.deprecated("dojo.html.shadow has been moved to dojo.lfx.","0.5");dojo.html.shadow=dojo.lfx.shadow;