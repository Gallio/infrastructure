
({"displayName":"ITL","symbol":"\u20a4"})