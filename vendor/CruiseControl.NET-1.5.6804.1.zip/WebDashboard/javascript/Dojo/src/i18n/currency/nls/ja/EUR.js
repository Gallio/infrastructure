
({"displayName":"\u30e6\u30fc\u30ed","symbol":"\u20ac"})