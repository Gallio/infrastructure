
({"displayName":"\u30a4\u30f3\u30c9 \u30eb\u30d4\u30fc","symbol":"INR"})