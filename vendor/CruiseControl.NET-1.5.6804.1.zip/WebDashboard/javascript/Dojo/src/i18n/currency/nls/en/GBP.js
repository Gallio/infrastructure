
({"displayName":"British Pound Sterling","symbol":"\xa3"})