
({"displayName":"\u30a4\u30bf\u30ea\u30a2 \u30ea\u30e9","symbol":"\u20a4"})