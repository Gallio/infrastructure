
({"displayName":"Euro","symbol":"\u20ac"})