
({"displayName":"GBP","symbol":"\xa3"})