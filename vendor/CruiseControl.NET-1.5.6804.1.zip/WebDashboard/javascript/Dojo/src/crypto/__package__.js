
dojo.kwCompoundRequire({common:["dojo.crypto","dojo.crypto.MD5"]});dojo.provide("dojo.crypto.*");