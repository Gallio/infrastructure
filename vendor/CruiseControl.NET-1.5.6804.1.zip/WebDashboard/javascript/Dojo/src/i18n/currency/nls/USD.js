
({"displayName":"USD","symbol":"$"})