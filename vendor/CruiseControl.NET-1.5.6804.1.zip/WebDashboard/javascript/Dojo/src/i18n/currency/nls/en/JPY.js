
({"displayName":"Japanese Yen","symbol":"\xa5"})