
({"displayName":"JPY","symbol":"\xa5"})