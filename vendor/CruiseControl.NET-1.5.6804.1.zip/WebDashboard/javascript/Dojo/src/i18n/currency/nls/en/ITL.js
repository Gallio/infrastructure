
({"displayName":"Italian Lira","symbol":"\u20a4"})