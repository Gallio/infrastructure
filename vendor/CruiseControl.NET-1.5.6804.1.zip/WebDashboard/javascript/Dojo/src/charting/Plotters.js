
dojo.provide("dojo.charting.Plotters");dojo.requireIf(dojo.render.svg.capable,"dojo.charting.svg.Plotters");dojo.requireIf(dojo.render.vml.capable,"dojo.charting.vml.Plotters");