
dojo.provide("dojo.graphics.*");