
({"displayName":"\u092f\u0941\u0930\u094b","symbol":"\u20ac"})